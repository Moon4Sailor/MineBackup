﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MineBackup
{
    public partial class Form1 : Form
    {
        private string minecraftWorldsPath;
        private string backupFolderPath;
        private string backupInfoFilePath;
        bool drag = false;
        Point start_point = new Point(0, 0);
        public Form1()
        {
            InitializeComponent();
            InitializeCustomComponents();
            LoadBackupsFromFile();
        }
        private void InitializeCustomComponents()
        {
            //Plataforma do jogo.
            
            comboBoxPlatform.Items.AddRange(new string[] { "Java", "Bedrock" });
            comboBoxPlatform.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxPlatform.SelectedIndexChanged += ComboBoxPlatform_SelectedIndexChanged;
            this.Controls.Add(comboBoxPlatform);

            //Worlds listView
           
            listViewWorlds.View = View.Details;
            listViewWorlds.Columns.Add("Name", 150);
            listViewWorlds.Columns.Add("Space", 70);
            listViewWorlds.Columns.Add("Seed", 100);
            listViewWorlds.Columns.Add("Creation Date", 150);
            this.Controls.Add(listViewWorlds);

            //Backups ListView 
            listViewBackups.View = View.Details;
            listViewBackups.Columns.Add("Name", 150);
            listViewBackups.Columns.Add("Space", 70);
            listViewBackups.Columns.Add("Seed", 100);
            listViewBackups.Columns.Add("Backup Date", 150);
            this.Controls.Add(listViewBackups);

            //Backup Button
            btnBackup.Click += BtnBackup_Click;
            this.Controls.Add(btnBackup);
            
            // Initialize Status Label
            this.Controls.Add(lblStatus);
           
            // Delete Backup Button
            this.Controls.Add(btnDeleteBackup);

            // Set up backup folder and info file paths
            backupFolderPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "MinecraftBackups");
            backupInfoFilePath = Path.Combine(backupFolderPath, "backups.txt");

            // Create backup folder if not exists
            if (!Directory.Exists(backupFolderPath))
            {
                Directory.CreateDirectory(backupFolderPath);
            }
        }

        private void ComboBoxPlatform_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clear current worlds list
            listViewWorlds.Items.Clear();

            // Set Minecraft Worlds path based on platform
            if (comboBoxPlatform.SelectedItem.ToString() == "Java")
            {
                minecraftWorldsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), ".minecraft", "saves");
            }
            else if (comboBoxPlatform.SelectedItem.ToString() == "Bedrock")
            {
                minecraftWorldsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Packages", "Microsoft.MinecraftUWP_8wekyb3d8bbwe", "LocalState", "games", "com.mojang", "minecraftWorlds");
            }

            // Check if worlds folder exists and populate list
            if (Directory.Exists(minecraftWorldsPath))
            {
                var directories = Directory.GetDirectories(minecraftWorldsPath);
                foreach (var directory in directories)
                {
                    var worldName = new DirectoryInfo(directory).Name;
                    var creationDate = Directory.GetCreationTime(directory).ToString();
                    var size = GetDirectorySize(new DirectoryInfo(directory));
                    var seed = "N/A"; // Placeholder, you'd need to read this from the level.dat for Java

                    listViewWorlds.Items.Add(new ListViewItem(new[] { worldName, size, seed, creationDate }));
                }
            }
            else
            {
                MessageBox.Show("Minecraft worlds folder not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnBackup_Click(object sender, EventArgs e)
        {
            if (listViewWorlds.CheckedItems.Count == 0)
            {
                lblStatus.Text = "Please check at least one world to backup.";
                MessageBox.Show("Error: No worlds selected for backup.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (ListViewItem checkedWorld in listViewWorlds.CheckedItems)
            {
                var worldName = checkedWorld.SubItems[0].Text;
                var worldDirectory = Path.Combine(minecraftWorldsPath, worldName);
                var backupDirectory = Path.Combine(backupFolderPath, worldName);

                // Check if the world already exists in the backup list
                var existingBackupItem = listViewBackups.Items.Cast<ListViewItem>().FirstOrDefault(item => item.SubItems[0].Text == worldName);

                // If the world exists in the backup, remove the old backup first
                if (existingBackupItem != null)
                {
                    listViewBackups.Items.Remove(existingBackupItem); // Remove from the ListView
                    DeleteOldBackup(backupDirectory);                // Delete the old backup folder
                }

                try
                {
                    // Copy the world to the backup folder
                    CopyDirectory(worldDirectory, backupDirectory);

                    // Add the backup info to the list and file
                    var backupDate = DateTime.Now.ToString();
                    var size = GetDirectorySize(new DirectoryInfo(worldDirectory));
                    var seed = checkedWorld.SubItems[2].Text;

                    listViewBackups.Items.Add(new ListViewItem(new[] { worldName, size, seed, backupDate }));
                    UpdateBackupInfoFile(); // Update the backup info file after replacing
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error during backup of world '{worldName}': {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            lblStatus.Text = "Backup completed successfully!";
        }
        private void LoadBackupsFromFile()
        {
            // Check if backup info file exists
            if (File.Exists(backupInfoFilePath))
            {
                var lines = File.ReadAllLines(backupInfoFilePath);
                foreach (var line in lines)
                {
                    var parts = line.Split('|');
                    if (parts.Length == 4)
                    {
                        listViewBackups.Items.Add(new ListViewItem(parts));
                    }
                }
            }
        }

        private string GetDirectorySize(DirectoryInfo directoryInfo)
        {
            long size = directoryInfo.EnumerateFiles("*", SearchOption.AllDirectories).Sum(file => file.Length);
            return (size / (1024 * 1024)).ToString() + " MB";
        }

        private void CopyDirectory(string sourceDir, string destDir)
        {
            var dir = new DirectoryInfo(sourceDir);
            if (!Directory.Exists(destDir))
            {
                Directory.CreateDirectory(destDir);
            }

            foreach (var file in dir.GetFiles())
            {
                string targetFilePath = Path.Combine(destDir, file.Name);
                file.CopyTo(targetFilePath, true);
            }

            foreach (var subDir in dir.GetDirectories())
            {
                string newDestDir = Path.Combine(destDir, subDir.Name);
                CopyDirectory(subDir.FullName, newDestDir);
            }
        }
        //more codeee
        private void BtnDeleteBackup_Click(object sender, EventArgs e)
{
    if (listViewBackups.CheckedItems.Count == 0)
    {
        lblStatus.Text = "Please check at least one backup to delete.";
        MessageBox.Show("Error: No backups selected for deletion.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return;
    }

    foreach (ListViewItem checkedBackup in listViewBackups.CheckedItems)
    {
        var backupName = checkedBackup.SubItems[0].Text;
        var backupDirectory = Path.Combine(backupFolderPath, backupName);

        try
        {
            // Delete the backup directory
            if (Directory.Exists(backupDirectory))
            {
                Directory.Delete(backupDirectory, true); // Delete directory and contents
            }

            // Remove the item from ListView
            listViewBackups.Items.Remove(checkedBackup);

            // Update status
            lblStatus.Text = $"Backup '{backupName}' deleted.";

            // Update the backup information file
            UpdateBackupInfoFile();
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Error during deletion of backup '{backupName}': {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    lblStatus.Text = "Selected backups deleted successfully!";
}

        private void UpdateBackupInfoFile()
        {
            using (StreamWriter writer = new StreamWriter(backupInfoFilePath))
            {
                foreach (ListViewItem item in listViewBackups.Items)
                {
                    var worldName = item.SubItems[0].Text;
                    var size = item.SubItems[1].Text;
                    var seed = item.SubItems[2].Text;
                    var backupDate = item.SubItems[3].Text;

                    writer.WriteLine($"{worldName}|{size}|{seed}|{backupDate}");
                }
            }
        }

        private void DeleteOldBackup(string backupDirectory)
        {
            if (Directory.Exists(backupDirectory))
            {
                Directory.Delete(backupDirectory, true); // Delete directory and contents
            }
        }
    
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit(); // Exit the application
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            start_point = new Point(e.X, e.Y);
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag)
            {
                Point p = PointToScreen(e.Location);
                this.Location=new Point(p.X-start_point.X, p.Y - start_point.Y);

            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }
    }
}
